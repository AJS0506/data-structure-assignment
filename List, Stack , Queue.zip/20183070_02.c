#include<stdio.h>
#include<stdlib.h>


typedef struct _ArrayList
{	
	int arr[50];
	int dataNum;
	int data;
	int delposition; 
	
}ArrayList;


void getdata(ArrayList* list)
{
	int i;
	for(i=0; i<list->dataNum; i++)
	{
		printf("  %d",list->arr[i]);
	}
	printf("\n");
}


void DelData(ArrayList* list)
{
    int i;
    for(i=list->delposition; i<list->dataNum; i++)
    {
    	list->arr[i] = list->arr[i+1];
	}
	list->dataNum--;
}

	
int main()
{
	ArrayList* list = (ArrayList*)malloc(sizeof(ArrayList));
	list->dataNum = 0;
	
	printf("Enter 5 elements in array : ");
	
	int i = 0;
	for(i=0; i<5; i++)
	{
		scanf("%d",&list->arr[i]);
		list->dataNum++;
	}
	

	printf("Stored element in array :  ");
	getdata(list);
	
	
	while(list->dataNum != 0)
	{
	printf("\n");
	int delPosition;
	printf("Enter poss, of element to delete : ");
	scanf("%d",&delPosition);
	if(delPosition > list->dataNum)
	{
		printf("can not delete , Over ArrayList index!\n");
		continue;
	}
	list->delposition = delPosition-1;

     
    DelData(list); // ������ ���� �Լ� 
    
    
    printf("After deletion element in array : ");
	
	getdata(list);
}

    printf("ArrayList is empty");
	return 0;
}
