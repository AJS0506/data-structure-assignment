#include <stdio.h>
#include <stdlib.h>
#define STACKLEN 10  //������ ���� ���� 

typedef struct _STACK
{
	int arr[STACKLEN];
	int top; 
	int head;
}STACK;



void initStack(STACK* stack)
{
	stack->top = 0;
	stack->head = 0;
}

void push(STACK* stack)
{
	int addNum;
	char Re= 'y';
	while(Re == 'y')
	{	
	if(stack->top == STACKLEN)
	{
	printf("\nSTACK iS FULL\n\n\n");
	return ;
    }
	 
	printf("Enter element in stack : ");
	scanf("%d",&addNum);
	if(stack->top == STACKLEN)
	{
		printf("STACK IS FULL\n\n");
		return;
	}
	stack->arr[stack->top] = addNum;
	stack->top++;

    while(1)
	{
	printf("\n\nPushed an element (y/n)");
	scanf(" %c",&Re);
	if(Re != 'y'&& Re != 'n')
	{
	printf("Please input y or n\n");
	continue;
    }
    else
    {
    break;
    }
    

	}
	

	printf("\n\n"); 
    }
	
	return;
}


void pop(STACK* stack)
{
	if(stack->top == 0)
	{
		printf("STACK is empty\n\n\n");
		return;
	}
	char Re;
	int returndata = stack->arr[stack->top-1];
	stack->top--;
	printf("deleted data is : %d\n\n",returndata);
	while(1)
	{
	printf("Pushed an element (y/n)");
	scanf(" %c",&Re);
	if(Re != 'y'&& Re != 'n')
	{
	printf("Please input y or n\n");
	continue;
    }
    else
    {
    break;
    }
    }
	printf("\n\n");
	   		
	if(Re=='y')
	{
	int addNum;
	printf("Enter element in stack : ");
	scanf("%d",&addNum);
	printf("\n\n");
	
	if(stack->top >= STACKLEN)
	{
	printf("STACK IS FULL\n\n");
	return;
    }
	stack->arr[stack->top] = addNum;
	stack->top++;
	}
	
	return;
}


void display(STACK* stack)
{
	int i;
	for(i=stack->top-1; i>=0; i--)
	{
		printf("%d\n",stack->arr[i]);
	}
	printf("\n\n");
	
	char check = 'y';
	while(1)
	{
	printf("Pushed an element (y/n)");
	scanf(" %c",&check);
	if(check != 'y'&& check != 'n')
	{
	printf("Please input y or n\n");
	continue;
    }
    else
    {
    break;
    }
    }
	if(check == 'y')
	{
		int useradd;
		printf("\nEnter element in stack:");
		scanf("%d",&useradd);
		
		if(stack->top >= STACKLEN)
		{
			printf("STACK IS FULL\n\n");
			return;
		}
		else
		{
		stack->arr[stack->top] = useradd; 
		stack->top++;
		printf("\n\n");
		return;
	    }
	}
	else
	{
		return;
	}
	return;
	
}

int main()
{
	STACK* stack = (STACK*)malloc(sizeof(STACK));
	initStack(stack);
	
	
	while(1)
	{
		
    int userchoice;
	printf("1: push\n");
	printf("2: pop\n");
	printf("3: display\n");
	printf("4: exit\n");

	printf("enter yout choice : ");
	scanf("%d",&userchoice);
	printf("\n");
	
	switch(userchoice)
	{
	    case 4: 
	    {
	     	exit(-1);
	    }
	   
	    case 1:
       	{
       		push(stack);
	  	    break;
	    }
	    case 2:
	   	{
		    pop(stack);
		    break;	    
	    }
	    case 3:
	    {
	     	display(stack);
			break;
		}	
		default:
			{
				printf("Error. Please input 1~4\n");
				exit(-1);
			}
	     	
	}
	
    }  
   
    free(stack);
	return 0;
}
