#include <stdio.h>
#include <stdlib.h> 
#define ARRAYLEN 10 // �迭�� ���̼��� 

typedef struct _ArrayList 
{	
	int arr[ARRAYLEN];
	int dataNum;
	int data;
	int position; 
}ArrayList;




void setdata(ArrayList* list,int data) //�����͸� �Է��ϴ� �Լ�
{
	int i;
	for(i=list->dataNum; i>list->position; i--)
    {
    	list->arr[i] = list->arr[i-1];
	}
	list->dataNum++;
	list->arr[list->position] = data;
}




void getdata(ArrayList* list) //�����͸� ����ϴ� �Լ� 
{
	int i;
	for(i=0; i<list->dataNum; i++)
    {
    	printf("  %d",list->arr[i]);
	}
	printf("\n");
}
	
	
	
int main()
{
	ArrayList* list = (ArrayList*)malloc(sizeof(ArrayList));
	list->dataNum = 0;
	
	printf("Enter 5 elements in array : ");
	
	int i = 0;
	for(i=0; i<5; i++)
	{
		scanf("%d",&list->arr[i]);
		list->dataNum++;
	}
	

	printf("Stored element in array :  ");
	
	getdata(list);
	
	while(list->dataNum != ARRAYLEN)
	{
	
	int userPosition;
	while(1)
	{
	printf("Enter position for enter element : ");
	scanf("%d",&userPosition);
	if(userPosition>=1)
	break;
	else
	printf("Please input > 0\n");
    }
	list->position = userPosition-1;
	
	if(userPosition > list->dataNum+1)
    {
    	printf("ARRAY INDEX OVER ERROR.\n\n");
    	continue;
	}
    
    int userElement;
    printf("Enter new element :  ");
    scanf("%d",&userElement);
    

    
    setdata(list,userElement);
    getdata(list);
    
   }
   
    printf("ArrayList is FULL");
    
	return 0;
}
