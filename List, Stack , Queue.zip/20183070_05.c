
#include<stdio.h>
#include<stdlib.h>
#define QLEN 4  //ť�� ���� ���� 
 
typedef struct _Queue
{
	int arr[QLEN];
	int front; 
	int back;
}Queue;

int nextindex(int position)
{
    if(position == QLEN-1)
    {
    	return 0;
	}
	else
	return position+1;
}

void initializationQ(Queue* q)  //ť �ʱ�ȭ �Լ� 
{
  q->back = 0;
  q->front = 0;
}

int fullcheck(Queue* q) //Ǯ�̸� 1(TRUE) ��ȯ �ƴϸ� 0(FALSE) ��ȯ 
{
	if(nextindex(q->back) == q->front)
	return 1;
	else
	return 0;
}

int emptycheck(Queue* q) //������̸� 1(TRUE)��ȯ �ƴϸ� 0(FALSE) ��ȯ 
{
   if(q->back == q->front)
   return 1;
   else
   return 0; 
}

int InQ(Queue* q,int data) // ť�� �����ͻ���  
{
	if(fullcheck(q))
	{
		printf("Queue is Full\n");
		return 0; //FALSE ��ȯ 
	}
	else
	{
		q->back = nextindex(q->back);
		q->arr[q->back] = data;
		printf("Insertion is Success! \n");
		return 1; //TRUE ��ȯ  
	}

	
}
                                    
int DeQPrint(Queue* q) // ť�� ������ ���� 
{
	if(emptycheck(q))
	{
		return 0;
	}
	else
	{
		q->front = nextindex(q->front);
		return q->arr[q->front];
	}
}

int display(Queue* q,int dpfront) // ť�� ��������� 
{
  if(emptycheck(q))
  {
  	printf("Queue is empty\n");
  }
  else
  {
    return q->arr[nextindex(dpfront)];
  }
}


int main()
{
	Queue* q = (Queue*)malloc(sizeof(Queue)); //ť�� �� 
	initializationQ(q); //ť�� �ʱ�ȭ 
	int dataNum=0;
	
	int user;
	while(1) 
	{
		
		printf("\n1.Insertion \n");
	    printf("2.Deletion\n");
	    printf("3.Display\n");
	    printf("0.Exit");
	    printf("\n\n\n");
	    
		printf("Selection Option : ");
		scanf("%d",&user);
		printf("\n");
		
		switch(user)
		{
		 case 0:
		 {
		 	printf("Exit Programm");
		    exit(-1);
		 }
		 
		 case 1:
		 {
		 	int addNum;
		 	printf("Element :");
		 	scanf("%d",&addNum);
		 	
		 	int sucess = InQ(q,addNum);
		 	if(sucess == 1)
		 	dataNum++;
		 	break;
		 }
		 
		 case 2:
		 {
		    int delNum = DeQPrint(q);
		    if(delNum!=0)
		    {
		    printf("Deleted item : %d",delNum);
		    dataNum--;
		    }
		    else
		    {
		    	printf("Queue is empty!");
			}
		 	break;
		 }
		 
		 case 3:
		 {
		 	int i,result,dpfront;
		 	dpfront = q->front;
		 	for(i=0; i<dataNum; i++)
		 	{
		 	result = display(q,dpfront);
		 	printf("  %d",result);
		 	dpfront = nextindex(dpfront);
		    }
			break;	
		 }
		 
		 default:
		 {
		 	printf("Error plese input 0~3 command ");
		 	exit(-1);
		 	break;
		 }	
		} 
		
		
	}
	
	free(q);
	return 0;
}


 
